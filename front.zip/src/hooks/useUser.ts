﻿import { useState, useEffect } from "react";

interface User {
  username?: string;
  fullUsername?: string;
  domain?: string;
  success?: boolean;
}

const API_URL = "http://localhost:3000/backend/api/user";




const fetchUser = async (): Promise<User> => {
  const response = await fetch(API_URL, {
    method: "GET",
    credentials: "include", // crucial for Windows auth
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  });

  const text = await response.text();
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  if (text.trim().startsWith("<")) throw new Error("HTML returned instead of JSON");

  return JSON.parse(text);
};

export const useUser = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchUser()
      .then((data) => {
        if (!data || data.success === false) {
          throw new Error("User load failed");
        }
        setUser(data);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return { user, loading, error };
};
